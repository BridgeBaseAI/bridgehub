import React from 'react';

const DatasetGrid = ({ datasets, loading, selectedTag, availableTags, onTagFilter }) => {
  const LoadingSkeleton = () => (
    <div className="animate-pulse">
      <div className="bg-dark-800/50 rounded-xl p-6 border border-gray-700/50">
        <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
        <div className="h-3 bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-3 bg-gray-700 rounded w-2/3 mb-4"></div>
        <div className="flex space-x-2 mb-4">
          <div className="h-6 bg-gray-700 rounded-full w-16"></div>
          <div className="h-6 bg-gray-700 rounded-full w-20"></div>
        </div>
        <div className="h-10 bg-gray-700 rounded w-full"></div>
      </div>
    </div>
  );

  const DatasetCard = ({ dataset }) => (
    <div className="group bg-gradient-to-br from-dark-800/60 to-dark-900/60 backdrop-blur-xl rounded-xl p-6 border border-gray-700/50 hover:border-primary-500/50 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-primary-500/10 animate-fade-in">
      {/* Header */}
      <div className="mb-4">
        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-primary-300 transition-colors">
          {dataset.title}
        </h3>
        <p className="text-gray-300 text-sm leading-relaxed line-clamp-3">
          {dataset.description}
        </p>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-2 mb-4">
        {dataset.tags.map((tag, index) => (
          <span
            key={index}
            onClick={() => onTagFilter(tag)}
            className={`px-3 py-1 text-xs font-medium rounded-full cursor-pointer transition-all ${
              selectedTag === tag
                ? 'bg-primary-500 text-white'
                : 'bg-gray-700/50 text-gray-300 hover:bg-primary-500/20 hover:text-primary-300'
            }`}
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Metadata */}
      <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
        <div>
          <span className="text-gray-400">Format:</span>
          <p className="text-white font-medium">{dataset.format}</p>
        </div>
        <div>
          <span className="text-gray-400">Size:</span>
          <p className="text-white font-medium">{dataset.size}</p>
        </div>
        <div>
          <span className="text-gray-400">Updates:</span>
          <p className="text-white font-medium">{dataset.updateFrequency}</p>
        </div>
        <div>
          <span className="text-gray-400">Use Cases:</span>
          <p className="text-white font-medium">{dataset.useCases.length}+</p>
        </div>
      </div>

      {/* Use Cases */}
      <div className="mb-6">
        <p className="text-gray-400 text-sm mb-2">Popular Use Cases:</p>
        <ul className="text-sm text-gray-300 space-y-1">
          {dataset.useCases.slice(0, 2).map((useCase, index) => (
            <li key={index} className="flex items-center">
              <span className="w-1.5 h-1.5 bg-primary-400 rounded-full mr-2"></span>
              {useCase}
            </li>
          ))}
          {dataset.useCases.length > 2 && (
            <li className="text-gray-400 text-xs">+{dataset.useCases.length - 2} more...</li>
          )}
        </ul>
      </div>

      {/* Action Button */}
      <a
        href={dataset.source}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full inline-flex items-center justify-center px-4 py-3 bg-gradient-to-r from-primary-600 to-purple-600 hover:from-primary-500 hover:to-purple-500 text-white font-medium rounded-lg transition-all duration-200 transform group-hover:scale-105"
      >
        <span>Access Dataset</span>
        <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
        </svg>
      </a>
    </div>
  );

  return (
    <section id="datasets" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Curated Web3 
            </span>
            <span className="bg-gradient-to-r from-primary-400 to-purple-500 bg-clip-text text-transparent">
              {" "}Datasets
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Access high-quality blockchain data from trusted sources. Perfect for research, analytics, and building next-generation Web3 applications.
          </p>
        </div>

        {/* Filter Tags */}
        {availableTags.length > 0 && (
          <div className="mb-8">
            <div className="flex flex-wrap gap-3 justify-center">
              <button
                onClick={() => onTagFilter('')}
                className={`px-4 py-2 rounded-full font-medium transition-all ${
                  selectedTag === ''
                    ? 'bg-primary-500 text-white shadow-lg'
                    : 'bg-dark-800/50 text-gray-300 hover:bg-primary-500/20 hover:text-primary-300 border border-gray-600/50'
                }`}
              >
                All ({datasets.length || 0})
              </button>
              {availableTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => onTagFilter(tag)}
                  className={`px-4 py-2 rounded-full font-medium transition-all capitalize ${
                    selectedTag === tag
                      ? 'bg-primary-500 text-white shadow-lg'
                      : 'bg-dark-800/50 text-gray-300 hover:bg-primary-500/20 hover:text-primary-300 border border-gray-600/50'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Dataset Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <LoadingSkeleton key={i} />
            ))}
          </div>
        ) : datasets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {datasets.map((dataset) => (
              <DatasetCard key={dataset.id} dataset={dataset} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gray-700/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-12 h-12 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-medium text-gray-300 mb-2">No datasets found</h3>
            <p className="text-gray-400">
              {selectedTag ? `No datasets found for "${selectedTag}" tag.` : 'No datasets available at the moment.'}
            </p>
            {selectedTag && (
              <button
                onClick={() => onTagFilter('')}
                className="mt-4 px-6 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-lg transition-colors"
              >
                Clear Filter
              </button>
            )}
          </div>
        )}

        {/* Stats */}
        {!loading && datasets.length > 0 && (
          <div className="mt-16 text-center">
            <div className="inline-flex items-center px-6 py-3 bg-dark-800/50 backdrop-blur-sm rounded-full border border-gray-700/50">
              <span className="text-gray-300">
                Showing {datasets.length} {datasets.length === 1 ? 'dataset' : 'datasets'}
                {selectedTag && (
                  <span className="text-primary-400"> • Filtered by "{selectedTag}"</span>
                )}
              </span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default DatasetGrid;