import React, { useState } from 'react';
import { askAIQuestion } from '../utils/api';

const AIChat = () => {
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim() || loading) return;

    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const result = await askAIQuestion(question.trim());
      if (result.success) {
        setResponse(result);
      } else {
        setError(result.message || 'Failed to get AI response');
      }
    } catch (err) {
      setError('Network error. Please check if the API server is running and OPENROUTER_API_KEY is configured.');
    } finally {
      setLoading(false);
    }
  };

  const suggestions = [
    "What are the best datasets for DeFi research?",
    "How can I analyze Bitcoin transaction patterns?",
    "What data sources exist for DAO governance analysis?",
    "Explain cross-chain analytics with Web3 data"
  ];

  return (
    <section id="ai-chat" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-primary-400 to-purple-500 bg-clip-text text-transparent">
              AI-Powered Assistant
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Ask questions about Web3 data, blockchain analytics, DeFi protocols, and get expert insights instantly.
          </p>
        </div>

        {/* Chat Interface */}
        <div className="bg-gradient-to-br from-dark-800/60 to-dark-900/60 backdrop-blur-xl rounded-2xl border border-gray-700/50 overflow-hidden shadow-2xl">
          {/* Chat Header */}
          <div className="bg-gradient-to-r from-primary-600/20 to-purple-600/20 border-b border-gray-700/50 p-6">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <span className="font-semibold text-primary-300">Web3 Data Expert</span>
              <span className="text-xs text-gray-400">Powered by DeepSeek AI</span>
            </div>
          </div>

          {/* Chat Content */}
          <div className="p-6">
            {/* Question Form */}
            <form onSubmit={handleSubmit} className="mb-6">
              <div className="relative">
                <textarea
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="Ask me anything about Web3 data, blockchain analytics, DeFi, NFTs, DAOs..."
                  className="w-full p-4 bg-dark-900/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  rows="3"
                  maxLength="1000"
                />
                <div className="absolute bottom-3 right-3 flex items-center space-x-3">
                  <span className="text-xs text-gray-500">
                    {question.length}/1000
                  </span>
                  <button
                    type="submit"
                    disabled={!question.trim() || loading}
                    className="px-6 py-2 bg-gradient-to-r from-primary-600 to-purple-600 hover:from-primary-500 hover:to-purple-500 disabled:from-gray-600 disabled:to-gray-600 text-white font-medium rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>Thinking...</span>
                      </div>
                    ) : (
                      'Ask AI'
                    )}
                  </button>
                </div>
              </div>
            </form>

            {/* Response Area */}
            {error && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 text-red-400 flex-shrink-0">⚠️</div>
                  <div>
                    <p className="text-red-300 font-medium">Error</p>
                    <p className="text-red-200 text-sm mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {response && (
              <div className="mb-6 animate-fade-in">
                <div className="bg-gradient-to-br from-primary-500/10 to-purple-500/10 border border-primary-500/30 rounded-xl p-6">
                  <div className="flex items-start space-x-3 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-sm font-bold">AI</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-primary-300 mb-2">Response:</p>
                      <div className="prose prose-invert max-w-none">
                        <p className="text-gray-200 leading-relaxed whitespace-pre-wrap">
                          {response.answer}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Response Metadata */}
                  <div className="flex flex-wrap gap-4 text-xs text-gray-400 mt-4 pt-4 border-t border-gray-600/30">
                    <span>Model: {response.model}</span>
                    <span>Response Time: {response.metadata?.response_time_ms}ms</span>
                    {response.metadata?.tokens_used && (
                      <span>Tokens: {response.metadata.tokens_used}</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Suggested Questions */}
            {!response && !error && (
              <div>
                <p className="text-sm text-gray-400 mb-3">Try asking:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {suggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => setQuestion(suggestion)}
                      className="text-left p-3 bg-dark-800/50 hover:bg-dark-700/50 border border-gray-600/50 hover:border-primary-500/50 rounded-lg transition-all text-sm text-gray-300 hover:text-white"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIChat;