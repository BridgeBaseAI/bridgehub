import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AIChat from './components/AIChat';
import DatasetGrid from './components/DatasetGrid';
import Footer from './components/Footer';
import { fetchDatasets } from './utils/api';

function App() {
  const [datasets, setDatasets] = useState([]);
  const [filteredDatasets, setFilteredDatasets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTag, setSelectedTag] = useState('');
  const [availableTags, setAvailableTags] = useState([]);

  useEffect(() => {
    loadDatasets();
  }, []);

  const loadDatasets = async () => {
    try {
      setLoading(true);
      const response = await fetchDatasets();
      if (response.success) {
        setDatasets(response.datasets);
        setFilteredDatasets(response.datasets);
        setAvailableTags(response.available_tags || []);
      }
    } catch (error) {
      console.error('Failed to load datasets:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTagFilter = (tag) => {
    setSelectedTag(tag);
    if (tag === '') {
      setFilteredDatasets(datasets);
    } else {
      const filtered = datasets.filter(dataset => 
        dataset.tags.some(t => t.toLowerCase().includes(tag.toLowerCase()))
      );
      setFilteredDatasets(filtered);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 text-white">
      <div className="fixed inset-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 25% 25%, rgba(99, 102, 241, 0.1) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(139, 92, 246, 0.1) 0%, transparent 50%)'
        }}></div>
      </div>
      
      <div className="relative z-10">
        <Navbar />
        <Hero />
        <AIChat />
        <DatasetGrid 
          datasets={filteredDatasets}
          loading={loading}
          selectedTag={selectedTag}
          availableTags={availableTags}
          onTagFilter={handleTagFilter}
        />
        <Footer />
      </div>
    </div>
  );
}

export default App;