const API_BASE_URL = 'http://localhost:5000';

// Fetch datasets from the API
export const fetchDatasets = async (tag = '', limit = '') => {
  try {
    const params = new URLSearchParams();
    if (tag) params.append('tag', tag);
    if (limit) params.append('limit', limit);
    
    const url = `${API_BASE_URL}/api/datasets${params.toString() ? '?' + params.toString() : ''}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching datasets:', error);
    throw error;
  }
};

// Ask AI question via the API
export const askAIQuestion = async (question) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/ask`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ question })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error asking AI question:', error);
    throw error;
  }
};