const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const datasetsRoutes = require('./routes/datasets');
const askRoutes = require('./routes/ask');

const app = express();
const PORT = process.env.PORT || 5000;

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again later.',
    code: 'RATE_LIMIT_EXCEEDED'
  }
});

// AI endpoint specific rate limiting (more restrictive)
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // limit each IP to 10 AI requests per minute
  message: {
    error: 'Too many AI requests, please wait before asking another question.',
    code: 'AI_RATE_LIMIT_EXCEEDED'
  }
});

// Middleware
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Apply rate limiting
app.use(limiter);

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path} - IP: ${req.ip}`);
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'BridgeBase Datasets Hub API',
    version: '1.0.0'
  });
});

// API Routes
app.use('/api/datasets', datasetsRoutes);
app.use('/api/ask', aiLimiter, askRoutes);

// Root endpoint with API information
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'BridgeBase Datasets Hub API',
    description: 'A Node.js backend API providing curated Web3 datasets and AI-powered Q&A',
    project: 'https://bridgebaseai.github.io/Bridgebaseai-v1/',
    endpoints: {
      datasets: '/api/datasets - Get curated Web3 datasets',
      ask: '/api/ask - AI-powered Q&A about Web3, data, and blockchain',
      health: '/health - Service health check'
    },
    version: '1.0.0'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  // Handle specific error types
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({
      error: 'Invalid JSON format in request body',
      code: 'INVALID_JSON'
    });
  }
  
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      error: 'Request payload too large',
      code: 'PAYLOAD_TOO_LARGE'
    });
  }

  // Generic error response
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    code: err.code || 'INTERNAL_ERROR',
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    code: 'NOT_FOUND',
    available_endpoints: ['/api/datasets', '/api/ask', '/health']
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 BridgeBase Datasets Hub API running on http://0.0.0.0:${PORT}`);
  console.log(`📊 Datasets endpoint: http://0.0.0.0:${PORT}/api/datasets`);
  console.log(`🤖 AI Q&A endpoint: http://0.0.0.0:${PORT}/api/ask`);
  console.log(`❤️  Health check: http://0.0.0.0:${PORT}/health`);
});

module.exports = app;
