const express = require('express');
const router = express.Router();
const web3Datasets = require('../data/web3-datasets');

// GET /api/datasets - Return curated Web3 datasets
router.get('/', (req, res) => {
  try {
    const { tag, limit } = req.query;
    
    let datasets = web3Datasets.getAllDatasets();
    
    // Filter by tag if provided
    if (tag) {
      const tagFilter = tag.toLowerCase();
      datasets = datasets.filter(dataset => 
        dataset.tags.some(t => t.toLowerCase().includes(tagFilter))
      );
    }
    
    // Apply limit if provided
    if (limit) {
      const limitNum = parseInt(limit);
      if (limitNum > 0 && limitNum <= 50) {
        datasets = datasets.slice(0, limitNum);
      }
    }
    
    // Response with metadata
    const response = {
      success: true,
      count: datasets.length,
      datasets: datasets,
      metadata: {
        total_available: web3Datasets.getAllDatasets().length,
        filtered_by_tag: tag || null,
        applied_limit: limit || null,
        timestamp: new Date().toISOString()
      },
      available_tags: web3Datasets.getAllTags()
    };
    
    res.status(200).json(response);
    
  } catch (error) {
    console.error('Error fetching datasets:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch datasets',
      code: 'DATASETS_FETCH_ERROR',
      message: 'An error occurred while retrieving the Web3 datasets'
    });
  }
});

// GET /api/datasets/tags/list - Get all available tags
router.get('/tags/list', (req, res) => {
  try {
    const tags = web3Datasets.getAllTags();
    
    res.status(200).json({
      success: true,
      tags: tags,
      count: tags.length,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Error fetching tags:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch tags',
      code: 'TAGS_FETCH_ERROR',
      message: 'An error occurred while retrieving available tags'
    });
  }
});

// GET /api/datasets/get/:id - Get specific dataset by ID
router.get('/get/:id', (req, res) => {
  try {
    const { id } = req.params;
    const dataset = web3Datasets.getDatasetById(id);
    
    if (!dataset) {
      return res.status(404).json({
        success: false,
        error: 'Dataset not found',
        code: 'DATASET_NOT_FOUND',
        message: `No dataset found with ID: ${id}`
      });
    }
    
    res.status(200).json({
      success: true,
      dataset: dataset,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Error fetching dataset by ID:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dataset',
      code: 'DATASET_FETCH_ERROR',
      message: 'An error occurred while retrieving the requested dataset'
    });
  }
});

module.exports = router;
