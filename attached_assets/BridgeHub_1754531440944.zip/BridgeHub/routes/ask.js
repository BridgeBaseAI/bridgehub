const express = require('express');
const router = express.Router();
const { validateQuestion } = require('../middleware/validation');
const openRouterService = require('../services/openrouter');

// POST /api/ask - AI-powered Q&A about Web3, data, and blockchain
router.post('/', validateQuestion, async (req, res) => {
  try {
    const { question } = req.body;
    
    console.log(`Processing AI question: "${question.substring(0, 100)}..."`);
    
    // Call OpenRouter API with DeepSeek model
    const aiResponse = await openRouterService.askQuestion(question);
    
    if (!aiResponse || !aiResponse.answer) {
      return res.status(500).json({
        success: false,
        error: 'Failed to get AI response',
        code: 'AI_RESPONSE_ERROR',
        message: 'The AI service did not return a valid response'
      });
    }
    
    // Successful response
    res.status(200).json({
      success: true,
      question: question,
      answer: aiResponse.answer,
      model: aiResponse.model || 'deepseek/deepseek-chat',
      metadata: {
        response_time_ms: aiResponse.responseTime,
        tokens_used: aiResponse.tokensUsed,
        timestamp: new Date().toISOString(),
        context: 'Web3, Blockchain, and Data Analytics'
      }
    });
    
  } catch (error) {
    console.error('Error in AI Q&A endpoint:', error);
    
    // Handle specific error types
    if (error.code === 'OPENROUTER_API_ERROR') {
      return res.status(502).json({
        success: false,
        error: 'AI service temporarily unavailable',
        code: 'AI_SERVICE_UNAVAILABLE',
        message: 'The AI service is currently experiencing issues. Please try again later.'
      });
    }
    
    if (error.code === 'INVALID_API_KEY') {
      return res.status(500).json({
        success: false,
        error: 'AI service configuration error',
        code: 'AI_CONFIG_ERROR',
        message: 'There is an issue with the AI service configuration'
      });
    }
    
    if (error.code === 'RATE_LIMIT_ERROR') {
      return res.status(429).json({
        success: false,
        error: 'AI service rate limit exceeded',
        code: 'AI_RATE_LIMIT',
        message: 'Too many requests to the AI service. Please wait before trying again.'
      });
    }
    
    // Generic error response
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      code: 'INTERNAL_ERROR',
      message: 'An unexpected error occurred while processing your question'
    });
  }
});

// GET /api/ask/status - Check AI service status
router.get('/status', async (req, res) => {
  try {
    const status = await openRouterService.checkStatus();
    
    res.status(200).json({
      success: true,
      ai_service_status: status.available ? 'available' : 'unavailable',
      model: 'deepseek/deepseek-chat',
      last_check: new Date().toISOString(),
      details: status.details || 'Service status checked successfully'
    });
    
  } catch (error) {
    console.error('Error checking AI service status:', error);
    res.status(503).json({
      success: false,
      ai_service_status: 'unavailable',
      error: 'Unable to check AI service status',
      code: 'STATUS_CHECK_ERROR'
    });
  }
});

module.exports = router;
