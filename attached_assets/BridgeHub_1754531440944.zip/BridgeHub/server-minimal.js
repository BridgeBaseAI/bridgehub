const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Web3 datasets data
const web3Datasets = [
  {
    id: "dolthub-bitcoin",
    title: "Bitcoin Blockchain Data on DoltHub",
    description: "Complete Bitcoin blockchain dataset with versioned SQL access. Includes blocks, transactions, inputs, and outputs with Git-like version control for data collaboration.",
    source: "https://www.dolthub.com/repositories/web3/bitcoin",
    tags: ["bitcoin", "blockchain", "transactions", "sql", "versioned"],
    format: "SQL Database",
    size: "~500GB+",
    updateFrequency: "Real-time",
    useCases: ["Bitcoin transaction analysis", "Blockchain research", "Data science projects", "Cross-chain analytics"]
  },
  {
    id: "aws-ethereum-bitcoin",
    title: "AWS Open Data - Bitcoin & Ethereum Datasets",
    description: "Public Bitcoin and Ethereum blockchain datasets on AWS for cross-chain analytics and research. Free access through AWS Open Data program.",
    source: "https://aws.amazon.com/blogs/web3/access-bitcoin-and-ethereum-open-datasets-for-cross-chain-analytics/",
    tags: ["ethereum", "bitcoin", "aws", "analytics", "cross-chain"],
    format: "Various (Parquet, JSON)",
    size: "Multi-TB",
    updateFrequency: "Daily",
    useCases: ["Cross-chain transaction analysis", "Mining difficulty trends", "Token volume analysis", "DeFi protocol research"]
  },
  {
    id: "forta-security-datasets",
    title: "Forta Network - Web3 Security Datasets",
    description: "Labeled datasets for Web3 threat detection and security analysis. Covers malicious smart contracts, exploit addresses, and phishing data across multiple chains.",
    source: "https://github.com/forta-network/labelled-datasets",
    tags: ["security", "threats", "ethereum", "malware", "phishing"],
    format: "CSV files",
    size: "~100MB",
    updateFrequency: "Weekly",
    useCases: ["Threat detection models", "Security analytics", "Fraud prevention", "Risk assessment tools"]
  },
  {
    id: "bigquery-web3-public",
    title: "BigQuery Public Web3 Datasets",
    description: "Comprehensive blockchain datasets available through Google Cloud BigQuery. Includes Ethereum, Bitcoin, and other major blockchain networks with SQL querying interface.",
    source: "https://cloud.google.com/application/web3/learn/bigquery-public-datasets",
    tags: ["ethereum", "bitcoin", "sql", "analytics", "gcp"],
    format: "BigQuery Tables",
    size: "Multi-PB",
    updateFrequency: "Real-time to Daily",
    useCases: ["Large-scale blockchain analytics", "DeFi protocol analysis", "Token economics research", "Network behavior studies"]
  },
  {
    id: "dolthub-ethereum",
    title: "Ethereum Data on DoltHub",
    description: "Versioned Ethereum blockchain data with collaborative features. Includes smart contract interactions, token transfers, and DeFi protocol data.",
    source: "https://www.dolthub.com/repositories/web3/ethereum",
    tags: ["ethereum", "defi", "smart-contracts", "tokens", "versioned"],
    format: "SQL Database",
    size: "~1TB+",
    updateFrequency: "Real-time",
    useCases: ["DeFi analytics", "Token economics analysis", "Smart contract research", "Ethereum ecosystem studies"]
  }
];

// OpenRouter service
class OpenRouterService {
  constructor() {
    this.apiKey = process.env.OPENROUTER_API_KEY;
    this.baseUrl = 'https://openrouter.ai/api/v1';
    this.model = 'deepseek/deepseek-chat';
  }

  async askQuestion(question) {
    const startTime = Date.now();
    
    if (!this.apiKey) {
      throw new Error('OpenRouter API key is required but not configured');
    }

    const systemPrompt = `You are an expert AI assistant specialized in Web3, blockchain technology, decentralized finance (DeFi), NFTs, DAOs, cryptocurrency, data analytics, and AI applications in the blockchain space. 

Your expertise includes:
- Blockchain fundamentals (Bitcoin, Ethereum, Layer 2 solutions)
- Smart contracts and DApps development
- DeFi protocols and yield farming strategies  
- NFT marketplaces and digital asset management
- DAO governance and tokenomics
- Cross-chain interoperability
- Web3 data analytics and on-chain analysis
- AI applications in blockchain and crypto
- Dataset curation and analysis for Web3 projects

Provide accurate, detailed, and actionable responses. When discussing datasets, recommend specific sources like DoltHub, BigQuery public datasets, Dune Analytics, or Flipside Crypto when relevant. Focus on practical applications and real-world use cases.`;

    const requestData = {
      model: this.model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: question }
      ],
      temperature: 0.7,
      max_tokens: 1000
    };

    const response = await axios.post(
      `${this.baseUrl}/chat/completions`,
      requestData,
      { 
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://bridgebaseai.github.io/',
          'X-Title': 'BridgeBase Datasets Hub'
        },
        timeout: 30000
      }
    );

    const responseTime = Date.now() - startTime;
    const aiAnswer = response.data.choices[0].message.content.trim();
    const tokensUsed = response.data.usage ? response.data.usage.total_tokens : null;

    return {
      answer: aiAnswer,
      model: this.model,
      responseTime: responseTime,
      tokensUsed: tokensUsed
    };
  }
}

const openRouterService = new OpenRouterService();

// Basic middleware
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path} - IP: ${req.ip}`);
  next();
});

// Root endpoint with API information
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'BridgeBase Datasets Hub API',
    description: 'A Node.js backend API providing curated Web3 datasets and AI-powered Q&A',
    project: 'https://bridgebaseai.github.io/Bridgebaseai-v1/',
    endpoints: {
      datasets: '/api/datasets - Get curated Web3 datasets',
      ask: '/api/ask - AI-powered Q&A about Web3, data, and blockchain',
      health: '/health - Service health check'
    },
    version: '1.0.0'
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'BridgeBase Datasets Hub API',
    version: '1.0.0'
  });
});

// GET /api/datasets - Return curated Web3 datasets
app.get('/api/datasets', (req, res) => {
  try {
    const { tag, limit } = req.query;
    
    let datasets = [...web3Datasets];
    
    // Filter by tag if provided
    if (tag) {
      const tagFilter = tag.toLowerCase();
      datasets = datasets.filter(dataset => 
        dataset.tags.some(t => t.toLowerCase().includes(tagFilter))
      );
    }
    
    // Apply limit if provided
    if (limit) {
      const limitNum = parseInt(limit);
      if (limitNum > 0 && limitNum <= 50) {
        datasets = datasets.slice(0, limitNum);
      }
    }

    // Get all available tags
    const allTags = new Set();
    web3Datasets.forEach(dataset => {
      dataset.tags.forEach(tag => allTags.add(tag));
    });
    
    // Response with metadata
    res.status(200).json({
      success: true,
      count: datasets.length,
      datasets: datasets,
      metadata: {
        total_available: web3Datasets.length,
        filtered_by_tag: tag || null,
        applied_limit: limit || null,
        timestamp: new Date().toISOString()
      },
      available_tags: Array.from(allTags).sort()
    });
    
  } catch (error) {
    console.error('Error fetching datasets:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch datasets',
      code: 'DATASETS_FETCH_ERROR',
      message: 'An error occurred while retrieving the Web3 datasets'
    });
  }
});

// Basic input validation for questions
const validateQuestion = (req, res, next) => {
  const { question } = req.body;
  
  if (!question || typeof question !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Question is required and must be a string',
      code: 'INVALID_QUESTION'
    });
  }
  
  const trimmedQuestion = question.trim();
  if (trimmedQuestion.length < 3 || trimmedQuestion.length > 1000) {
    return res.status(400).json({
      success: false,
      error: 'Question must be between 3 and 1000 characters',
      code: 'INVALID_QUESTION_LENGTH'
    });
  }
  
  // Basic sanitization - remove HTML tags and dangerous characters
  req.body.question = trimmedQuestion.replace(/<[^>]*>/g, '').replace(/[<>"']/g, '');
  next();
};

// POST /api/ask - AI-powered Q&A about Web3
app.post('/api/ask', validateQuestion, async (req, res) => {
  try {
    const { question } = req.body;
    
    console.log(`Processing AI question: "${question.substring(0, 100)}..."`);
    
    // Call OpenRouter API with DeepSeek model
    const aiResponse = await openRouterService.askQuestion(question);
    
    if (!aiResponse || !aiResponse.answer) {
      return res.status(500).json({
        success: false,
        error: 'Failed to get AI response',
        code: 'AI_RESPONSE_ERROR',
        message: 'The AI service did not return a valid response'
      });
    }
    
    // Successful response
    res.status(200).json({
      success: true,
      question: question,
      answer: aiResponse.answer,
      model: aiResponse.model || 'deepseek/deepseek-chat',
      metadata: {
        response_time_ms: aiResponse.responseTime,
        tokens_used: aiResponse.tokensUsed,
        timestamp: new Date().toISOString(),
        context: 'Web3, Blockchain, and Data Analytics'
      }
    });
    
  } catch (error) {
    console.error('Error in AI Q&A endpoint:', error);
    
    // Handle specific error types
    if (error.message.includes('OpenRouter API key')) {
      return res.status(500).json({
        success: false,
        error: 'AI service configuration error',
        code: 'AI_CONFIG_ERROR',
        message: 'OpenRouter API key is required. Please configure OPENROUTER_API_KEY environment variable.'
      });
    }
    
    if (error.response?.status === 429) {
      return res.status(429).json({
        success: false,
        error: 'AI service rate limit exceeded',
        code: 'AI_RATE_LIMIT',
        message: 'Too many requests to the AI service. Please wait before trying again.'
      });
    }
    
    // Generic error response
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      code: 'INTERNAL_ERROR',
      message: 'An unexpected error occurred while processing your question'
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({
      success: false,
      error: 'Invalid JSON format in request body',
      code: 'INVALID_JSON'
    });
  }
  
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      success: false,
      error: 'Request payload too large',
      code: 'PAYLOAD_TOO_LARGE'
    });
  }

  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal server error',
    code: err.code || 'INTERNAL_ERROR',
    timestamp: new Date().toISOString()
  });
});

// 404 handler for undefined routes
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    code: 'NOT_FOUND',
    available_endpoints: ['/api/datasets', '/api/ask', '/health'],
    message: `The requested endpoint ${req.originalUrl} was not found`
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 BridgeBase Datasets Hub API running on http://0.0.0.0:${PORT}`);
  console.log(`📊 Datasets endpoint: http://0.0.0.0:${PORT}/api/datasets`);
  console.log(`🤖 AI Q&A endpoint: http://0.0.0.0:${PORT}/api/ask`);
  console.log(`❤️  Health check: http://0.0.0.0:${PORT}/health`);
  
  if (!process.env.OPENROUTER_API_KEY) {
    console.log(`⚠️  Warning: OpenRouter API key not found. AI Q&A endpoint will not work until OPENROUTER_API_KEY is set.`);
  }
});

module.exports = app;