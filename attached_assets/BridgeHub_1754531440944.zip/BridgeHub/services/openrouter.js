const axios = require('axios');

class OpenRouterService {
  constructor() {
    this.apiKey = process.env.OPENROUTER_API_KEY || process.env.OPENROUTER_KEY;
    this.baseUrl = 'https://openrouter.ai/api/v1';
    this.model = 'deepseek/deepseek-chat';
    this.maxRetries = 3;
    
    if (!this.apiKey) {
      console.warn('Warning: OpenRouter API key not found. Please set OPENROUTER_API_KEY environment variable.');
    }
  }

  async askQuestion(question, retryCount = 0) {
    const startTime = Date.now();
    
    try {
      if (!this.apiKey) {
        throw new Error('OpenRouter API key is required but not configured');
      }

      // Enhanced system prompt for Web3 focus
      const systemPrompt = `You are an expert AI assistant specialized in Web3, blockchain technology, decentralized finance (DeFi), NFTs, DAOs, cryptocurrency, data analytics, and AI applications in the blockchain space. 

Your expertise includes:
- Blockchain fundamentals (Bitcoin, Ethereum, Layer 2 solutions)
- Smart contracts and DApps development
- DeFi protocols and yield farming strategies  
- NFT marketplaces and digital asset management
- DAO governance and tokenomics
- Cross-chain interoperability
- Web3 data analytics and on-chain analysis
- AI applications in blockchain and crypto
- Dataset curation and analysis for Web3 projects

Provide accurate, detailed, and actionable responses. When discussing datasets, recommend specific sources like DoltHub, BigQuery public datasets, Dune Analytics, or Flipside Crypto when relevant. Focus on practical applications and real-world use cases.

If a question is outside your Web3/blockchain expertise, politely redirect to your specialized knowledge areas.`;

      const requestData = {
        model: this.model,
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: question
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0
      };

      const headers = {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://bridgebaseai.github.io/',
        'X-Title': 'BridgeBase Datasets Hub'
      };

      console.log('Sending request to OpenRouter API...');
      
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        requestData,
        { 
          headers,
          timeout: 30000 // 30 second timeout
        }
      );

      const responseTime = Date.now() - startTime;

      if (!response.data || !response.data.choices || !response.data.choices[0]) {
        throw new Error('Invalid response structure from OpenRouter API');
      }

      const aiAnswer = response.data.choices[0].message.content.trim();
      const tokensUsed = response.data.usage ? response.data.usage.total_tokens : null;

      console.log(`AI response received in ${responseTime}ms, tokens used: ${tokensUsed}`);

      return {
        answer: aiAnswer,
        model: this.model,
        responseTime: responseTime,
        tokensUsed: tokensUsed
      };

    } catch (error) {
      console.error(`OpenRouter API error (attempt ${retryCount + 1}):`, error.message);

      // Handle specific error cases
      if (error.response) {
        const status = error.response.status;
        const errorData = error.response.data;
        
        if (status === 401) {
          const apiError = new Error('Invalid OpenRouter API key');
          apiError.code = 'INVALID_API_KEY';
          throw apiError;
        }
        
        if (status === 429) {
          const apiError = new Error('Rate limit exceeded for OpenRouter API');
          apiError.code = 'RATE_LIMIT_ERROR';
          throw apiError;
        }
        
        if (status >= 500) {
          // Retry on server errors
          if (retryCount < this.maxRetries) {
            console.log(`Retrying request in 2 seconds... (attempt ${retryCount + 1}/${this.maxRetries})`);
            await new Promise(resolve => setTimeout(resolve, 2000));
            return this.askQuestion(question, retryCount + 1);
          }
        }
        
        console.error('OpenRouter API error details:', errorData);
      }

      // Handle network errors
      if (error.code === 'ECONNABORTED' || error.code === 'ENOTFOUND') {
        const networkError = new Error('Network error connecting to OpenRouter API');
        networkError.code = 'NETWORK_ERROR';
        throw networkError;
      }

      // Generic API error
      const apiError = new Error(`OpenRouter API request failed: ${error.message}`);
      apiError.code = 'OPENROUTER_API_ERROR';
      throw apiError;
    }
  }

  async checkStatus() {
    try {
      if (!this.apiKey) {
        return {
          available: false,
          details: 'API key not configured'
        };
      }

      // Test with a simple question to verify API connectivity
      const testQuestion = "What is blockchain?";
      await this.askQuestion(testQuestion);
      
      return {
        available: true,
        details: 'OpenRouter API is responding normally'
      };
      
    } catch (error) {
      return {
        available: false,
        details: `API check failed: ${error.message}`
      };
    }
  }
}

module.exports = new OpenRouterService();
