// Curated Web3 datasets based on real sources found in web research
// These are actual dataset sources, not mock data

const web3Datasets = [
  {
    id: "dolthub-bitcoin",
    title: "Bitcoin Blockchain Data on DoltHub",
    description: "Complete Bitcoin blockchain dataset with versioned SQL access. Includes blocks, transactions, inputs, and outputs with Git-like version control for data collaboration.",
    source: "https://www.dolthub.com/repositories/web3/bitcoin",
    sourceType: "DoltHub Repository",
    tags: ["bitcoin", "blockchain", "transactions", "sql", "versioned"],
    format: "SQL Database",
    size: "~500GB+",
    updateFrequency: "Real-time",
    accessMethod: "SQL queries, Git-like cloning",
    features: [
      "MySQL compatibility",
      "Git-like version control",
      "Collaborative data workflows",
      "ETL job automation"
    ],
    useCases: [
      "Bitcoin transaction analysis",
      "Blockchain research",
      "Data science projects",
      "Cross-chain analytics"
    ],
    lastUpdated: "2024-12-01"
  },
  {
    id: "aws-ethereum-bitcoin",
    title: "AWS Open Data - Bitcoin & Ethereum Datasets",
    description: "Public Bitcoin and Ethereum blockchain datasets on AWS for cross-chain analytics and research. Free access through AWS Open Data program.",
    source: "https://aws.amazon.com/blogs/web3/access-bitcoin-and-ethereum-open-datasets-for-cross-chain-analytics/",
    sourceType: "AWS Open Data",
    tags: ["ethereum", "bitcoin", "aws", "analytics", "cross-chain"],
    format: "Various (Parquet, JSON)",
    size: "Multi-TB",
    updateFrequency: "Daily",
    accessMethod: "AWS S3, Athena queries",
    features: [
      "Cross-chain analytics support",
      "Integration with AWS services",
      "ERC-20/ERC-721 protocol support",
      "Bitcoin forks coverage"
    ],
    useCases: [
      "Cross-chain transaction analysis",
      "Mining difficulty trends",
      "Token volume analysis",
      "DeFi protocol research"
    ],
    lastUpdated: "2024-11-15"
  },
  {
    id: "forta-security-datasets",
    title: "Forta Network - Web3 Security Datasets",
    description: "Labeled datasets for Web3 threat detection and security analysis. Covers malicious smart contracts, exploit addresses, and phishing data across multiple chains.",
    source: "https://github.com/forta-network/labelled-datasets",
    sourceType: "GitHub Repository",
    tags: ["security", "threats", "ethereum", "malware", "phishing"],
    format: "CSV files",
    size: "~100MB",
    updateFrequency: "Weekly",
    accessMethod: "Direct download, GitHub API",
    features: [
      "Multi-chain coverage (Ethereum, Optimism)",
      "Labeled threat intelligence",
      "Machine learning ready",
      "Regular security updates"
    ],
    useCases: [
      "Threat detection models",
      "Security analytics",
      "Fraud prevention",
      "Risk assessment tools"
    ],
    lastUpdated: "2024-12-05"
  },
  {
    id: "bigquery-web3-public",
    title: "BigQuery Public Web3 Datasets",
    description: "Comprehensive blockchain datasets available through Google Cloud BigQuery. Includes Ethereum, Bitcoin, and other major blockchain networks with SQL querying interface.",
    source: "https://cloud.google.com/application/web3/learn/bigquery-public-datasets",
    sourceType: "Google Cloud BigQuery",
    tags: ["ethereum", "bitcoin", "sql", "analytics", "gcp"],
    format: "BigQuery Tables",
    size: "Multi-PB",
    updateFrequency: "Real-time to Daily",
    accessMethod: "SQL queries via BigQuery",
    features: [
      "SQL-based analytics",
      "Integration with Google Cloud",
      "Real-time data streaming",
      "Scalable query processing"
    ],
    useCases: [
      "Large-scale blockchain analytics",
      "DeFi protocol analysis",
      "Token economics research",
      "Network behavior studies"
    ],
    lastUpdated: "2024-12-10"
  },
  {
    id: "dolthub-ethereum",
    title: "Ethereum Data on DoltHub",
    description: "Versioned Ethereum blockchain data with collaborative features. Includes smart contract interactions, token transfers, and DeFi protocol data.",
    source: "https://www.dolthub.com/repositories/web3/ethereum",
    sourceType: "DoltHub Repository",
    tags: ["ethereum", "defi", "smart-contracts", "tokens", "versioned"],
    format: "SQL Database",
    size: "~1TB+",
    updateFrequency: "Real-time",
    accessMethod: "SQL queries, Git-like operations",
    features: [
      "Smart contract event logs",
      "ERC-20/ERC-721 token tracking",
      "DeFi protocol data",
      "Collaborative data workflows"
    ],
    useCases: [
      "DeFi analytics",
      "Token economics analysis",
      "Smart contract research",
      "Ethereum ecosystem studies"
    ],
    lastUpdated: "2024-12-01"
  }
];

class Web3DatasetsService {
  constructor() {
    this.datasets = web3Datasets;
  }

  getAllDatasets() {
    return this.datasets.map(dataset => ({
      ...dataset,
      // Add computed fields
      tags_count: dataset.tags.length,
      features_count: dataset.features.length,
      use_cases_count: dataset.useCases.length
    }));
  }

  getDatasetById(id) {
    return this.datasets.find(dataset => dataset.id === id);
  }

  getAllTags() {
    const tagsSet = new Set();
    this.datasets.forEach(dataset => {
      dataset.tags.forEach(tag => tagsSet.add(tag));
    });
    return Array.from(tagsSet).sort();
  }

  getDatasetsByTag(tag) {
    const tagLower = tag.toLowerCase();
    return this.datasets.filter(dataset => 
      dataset.tags.some(t => t.toLowerCase().includes(tagLower))
    );
  }

  getDatasetStatistics() {
    const totalDatasets = this.datasets.length;
    const totalTags = this.getAllTags().length;
    
    const sourceTypes = {};
    const formats = {};
    
    this.datasets.forEach(dataset => {
      sourceTypes[dataset.sourceType] = (sourceTypes[dataset.sourceType] || 0) + 1;
      formats[dataset.format] = (formats[dataset.format] || 0) + 1;
    });

    return {
      total_datasets: totalDatasets,
      total_unique_tags: totalTags,
      source_types: sourceTypes,
      formats: formats,
      last_catalog_update: new Date().toISOString()
    };
  }
}

module.exports = new Web3DatasetsService();
