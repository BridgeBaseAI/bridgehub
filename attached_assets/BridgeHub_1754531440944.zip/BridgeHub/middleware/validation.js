const validator = require('validator');

// Validation middleware for question input
const validateQuestion = (req, res, next) => {
  try {
    const { question } = req.body;
    
    // Check if question exists
    if (!question) {
      return res.status(400).json({
        success: false,
        error: 'Question is required',
        code: 'MISSING_QUESTION',
        message: 'Please provide a question in the request body'
      });
    }
    
    // Check if question is a string
    if (typeof question !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Question must be a string',
        code: 'INVALID_QUESTION_TYPE',
        message: 'The question field must contain text'
      });
    }
    
    // Trim and validate length
    const trimmedQuestion = question.trim();
    
    if (trimmedQuestion.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Question cannot be empty',
        code: 'EMPTY_QUESTION',
        message: 'Please provide a non-empty question'
      });
    }
    
    if (trimmedQuestion.length < 3) {
      return res.status(400).json({
        success: false,
        error: 'Question too short',
        code: 'QUESTION_TOO_SHORT',
        message: 'Question must be at least 3 characters long'
      });
    }
    
    if (trimmedQuestion.length > 1000) {
      return res.status(400).json({
        success: false,
        error: 'Question too long',
        code: 'QUESTION_TOO_LONG',
        message: 'Question must be no more than 1000 characters'
      });
    }
    
    // Basic XSS protection - escape HTML entities
    const sanitizedQuestion = validator.escape(trimmedQuestion);
    
    // Check for potentially malicious patterns
    const maliciousPatterns = [
      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
      /javascript:/gi,
      /vbscript:/gi,
      /onload\s*=/gi,
      /onerror\s*=/gi
    ];
    
    for (const pattern of maliciousPatterns) {
      if (pattern.test(question)) {
        return res.status(400).json({
          success: false,
          error: 'Invalid question format',
          code: 'INVALID_QUESTION_CONTENT',
          message: 'Question contains potentially harmful content'
        });
      }
    }
    
    // Add sanitized question to request
    req.body.question = sanitizedQuestion;
    
    next();
    
  } catch (error) {
    console.error('Validation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      message: 'An error occurred while validating the request'
    });
  }
};

// Validation for query parameters
const validateQueryParams = (req, res, next) => {
  try {
    const { tag, limit } = req.query;
    
    // Validate tag parameter
    if (tag !== undefined) {
      if (typeof tag !== 'string' || tag.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Invalid tag parameter',
          code: 'INVALID_TAG',
          message: 'Tag parameter must be a non-empty string'
        });
      }
      
      // Sanitize tag
      req.query.tag = validator.escape(tag.trim());
    }
    
    // Validate limit parameter
    if (limit !== undefined) {
      const limitNum = parseInt(limit);
      
      if (isNaN(limitNum) || limitNum < 1 || limitNum > 50) {
        return res.status(400).json({
          success: false,
          error: 'Invalid limit parameter',
          code: 'INVALID_LIMIT',
          message: 'Limit must be a number between 1 and 50'
        });
      }
      
      req.query.limit = limitNum.toString();
    }
    
    next();
    
  } catch (error) {
    console.error('Query validation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Query validation failed',
      code: 'QUERY_VALIDATION_ERROR',
      message: 'An error occurred while validating query parameters'
    });
  }
};

module.exports = {
  validateQuestion,
  validateQueryParams
};
