# Overview

This is a Node.js HTTP API server that provides curated Web3 datasets and AI-powered Q&A functionality for blockchain, cryptocurrency, and decentralized technology research. The system serves as a knowledge hub combining static dataset information with dynamic AI assistance specialized in Web3 topics.

The application offers two main services: a datasets endpoint that returns curated blockchain data sources from platforms like DoltHub and AWS Open Data, and an AI chat endpoint powered by OpenRouter's DeepSeek model for answering Web3-related questions.

**Recent Changes (August 2025):**
- Migrated from Express.js to native Node.js HTTP module to resolve path-to-regexp compatibility issues
- Implemented complete API with all endpoints functional
- Added comprehensive Web3 dataset catalog with real data sources
- Integrated OpenRouter AI service with proper error handling

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Backend Architecture
- **Framework**: Native Node.js HTTP module with RESTful API design (migrated from Express.js)
- **Entry Point**: `server-http.js` serving as the main application server
- **Port Configuration**: Configurable via environment variables (default: 5000)
- **Module Structure**: Monolithic structure with embedded dataset catalog and OpenRouter service class

## API Design Patterns
- **Route Organization**: URL-based routing handled in main server file with conditional logic
- **HTTP Module**: Direct HTTP request/response handling without Express framework
- **Error Handling**: Structured error responses with consistent format including success flags, error codes, and descriptive messages
- **Response Format**: Standardized JSON responses with metadata and timestamp information
- **CORS Support**: Built-in CORS headers for cross-origin requests

## Security and Input Validation
- **Input Validation**: Basic validation for question length (3-1000 characters) and type checking
- **Sanitization**: HTML tag removal and dangerous character filtering for user inputs
- **CORS Configuration**: Wildcard origin support with standard headers
- **Request Logging**: IP address and timestamp logging for all requests

## Data Management
- **Static Data**: Web3 datasets stored as JavaScript modules in `/data/` directory
- **Dataset Features**: Each dataset includes metadata like source, format, size, update frequency, and use cases
- **Data Sources**: Curated from real platforms including DoltHub, AWS Open Data, and other blockchain data providers

## AI Integration
- **Service Provider**: OpenRouter API integration for AI functionality
- **Model Selection**: DeepSeek Chat model optimized for Web3 and blockchain expertise
- **Specialization**: System prompts tailored for blockchain, DeFi, NFTs, DAOs, and cryptocurrency topics
- **Error Resilience**: Retry logic and graceful error handling for AI service failures

## Environment Configuration
- **Environment Variables**: Uses dotenv for configuration management
- **Required Variables**: OPENROUTER_API_KEY for AI functionality
- **Optional Variables**: PORT, ALLOWED_ORIGINS for customization

# External Dependencies

## Core Runtime Dependencies
- **dotenv**: Environment variable configuration management for API keys and settings
- **axios**: HTTP client for OpenRouter API communication
- **Node.js HTTP module**: Built-in HTTP server functionality (no Express dependency)

## AI Service Integration
- **OpenRouter API**: Third-party AI service providing access to DeepSeek chat model
- **Custom OpenRouterService class**: Handles API communication with retry logic and error handling

## Data Sources Referenced
- **DoltHub**: Versioned SQL database platform for Bitcoin blockchain data
- **AWS Open Data**: Public datasets for Bitcoin and Ethereum analytics
- **Various Web3 Data Platforms**: Referenced in dataset catalog for blockchain research

Note: The application currently operates without a persistent database, using static data files for dataset information and relying on external AI services for dynamic responses.