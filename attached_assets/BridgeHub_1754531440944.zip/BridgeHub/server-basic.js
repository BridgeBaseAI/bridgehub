const express = require('express');
const cors = require('cors');
require('dotenv').config();

const web3Datasets = require('./data/web3-datasets');
const { validateQuestion } = require('./middleware/validation');
const openRouterService = require('./services/openrouter');

const app = express();
const PORT = process.env.PORT || 5000;

// Basic middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path} - IP: ${req.ip}`);
  next();
});

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'BridgeBase Datasets Hub API',
    description: 'A Node.js backend API providing curated Web3 datasets and AI-powered Q&A',
    project: 'https://bridgebaseai.github.io/Bridgebaseai-v1/',
    endpoints: {
      datasets: '/api/datasets - Get curated Web3 datasets',
      ask: '/api/ask - AI-powered Q&A about Web3, data, and blockchain',
      health: '/health - Service health check'
    },
    version: '1.0.0'
  });
});

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'BridgeBase Datasets Hub API',
    version: '1.0.0'
  });
});

// GET /api/datasets - Return curated Web3 datasets
app.get('/api/datasets', (req, res) => {
  try {
    const { tag, limit } = req.query;
    
    let datasets = web3Datasets.getAllDatasets();
    
    // Filter by tag if provided
    if (tag) {
      const tagFilter = tag.toLowerCase();
      datasets = datasets.filter(dataset => 
        dataset.tags.some(t => t.toLowerCase().includes(tagFilter))
      );
    }
    
    // Apply limit if provided
    if (limit) {
      const limitNum = parseInt(limit);
      if (limitNum > 0 && limitNum <= 50) {
        datasets = datasets.slice(0, limitNum);
      }
    }
    
    // Response with metadata
    res.status(200).json({
      success: true,
      count: datasets.length,
      datasets: datasets,
      metadata: {
        total_available: web3Datasets.getAllDatasets().length,
        filtered_by_tag: tag || null,
        applied_limit: limit || null,
        timestamp: new Date().toISOString()
      },
      available_tags: web3Datasets.getAllTags()
    });
    
  } catch (error) {
    console.error('Error fetching datasets:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch datasets',
      code: 'DATASETS_FETCH_ERROR',
      message: 'An error occurred while retrieving the Web3 datasets'
    });
  }
});

// POST /api/ask - AI-powered Q&A
app.post('/api/ask', validateQuestion, async (req, res) => {
  try {
    const { question } = req.body;
    
    console.log(`Processing AI question: "${question.substring(0, 100)}..."`);
    
    // Call OpenRouter API with DeepSeek model
    const aiResponse = await openRouterService.askQuestion(question);
    
    if (!aiResponse || !aiResponse.answer) {
      return res.status(500).json({
        success: false,
        error: 'Failed to get AI response',
        code: 'AI_RESPONSE_ERROR',
        message: 'The AI service did not return a valid response'
      });
    }
    
    // Successful response
    res.status(200).json({
      success: true,
      question: question,
      answer: aiResponse.answer,
      model: aiResponse.model || 'deepseek/deepseek-chat',
      metadata: {
        response_time_ms: aiResponse.responseTime,
        tokens_used: aiResponse.tokensUsed,
        timestamp: new Date().toISOString(),
        context: 'Web3, Blockchain, and Data Analytics'
      }
    });
    
  } catch (error) {
    console.error('Error in AI Q&A endpoint:', error);
    
    // Handle specific error types
    if (error.code === 'OPENROUTER_API_ERROR') {
      return res.status(502).json({
        success: false,
        error: 'AI service temporarily unavailable',
        code: 'AI_SERVICE_UNAVAILABLE',
        message: 'The AI service is currently experiencing issues. Please try again later.'
      });
    }
    
    if (error.code === 'INVALID_API_KEY') {
      return res.status(500).json({
        success: false,
        error: 'AI service configuration error',
        code: 'AI_CONFIG_ERROR',
        message: 'There is an issue with the AI service configuration'
      });
    }
    
    if (error.code === 'RATE_LIMIT_ERROR') {
      return res.status(429).json({
        success: false,
        error: 'AI service rate limit exceeded',
        code: 'AI_RATE_LIMIT',
        message: 'Too many requests to the AI service. Please wait before trying again.'
      });
    }
    
    // Generic error response
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      code: 'INTERNAL_ERROR',
      message: 'An unexpected error occurred while processing your question'
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({
      error: 'Invalid JSON format in request body',
      code: 'INVALID_JSON'
    });
  }
  
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      error: 'Request payload too large',
      code: 'PAYLOAD_TOO_LARGE'
    });
  }

  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    code: err.code || 'INTERNAL_ERROR',
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    code: 'NOT_FOUND',
    available_endpoints: ['/api/datasets', '/api/ask', '/health']
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 BridgeBase Datasets Hub API running on http://0.0.0.0:${PORT}`);
  console.log(`📊 Datasets endpoint: http://0.0.0.0:${PORT}/api/datasets`);
  console.log(`🤖 AI Q&A endpoint: http://0.0.0.0:${PORT}/api/ask`);
  console.log(`❤️  Health check: http://0.0.0.0:${PORT}/health`);
});

module.exports = app;